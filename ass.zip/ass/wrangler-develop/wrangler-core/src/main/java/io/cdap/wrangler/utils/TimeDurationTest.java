package io.cdap.wrangler.utils;

import org.junit.Test;
import static org.junit.Assert.*;

public class TimeDurationTest {

    @Test
    public void testSecondsConversion() {
        TimeDuration td = new TimeDuration("5s");
        assertEquals(5000, td.getMilliseconds());
    }

    @Test
    public void testMinutesConversion() {
        TimeDuration td = new TimeDuration("2min");
        assertEquals(2 * 60 * 1000, td.getMilliseconds());
    }

    @Test
    public void testHoursConversion() {
        TimeDuration td = new TimeDuration("1h");
        assertEquals(1 * 60 * 60 * 1000, td.getMilliseconds());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidUnitThrowsException() {
        new TimeDuration("10x"); // Invalid unit
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMalformedInputThrowsException() {
        new TimeDuration("nonsense"); // Not a valid duration
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEmptyInputThrowsException() {
        new TimeDuration(""); // Empty string
    }
}
