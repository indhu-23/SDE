package io.cdap.wrangler.utils;

import org.junit.Test;
import static org.junit.Assert.*;

public class ByteSizeTest {

    @Test
    public void testMBConversion() {
        ByteSize bs = new ByteSize("1MB");
        assertEquals(1024 * 1024, bs.getBytes());
    }

    @Test
    public void testKBConversion() {
        ByteSize bs = new ByteSize("1KB");
        assertEquals(1024, bs.getBytes());
    }

    @Test
    public void testGBConversion() {
        ByteSize bs = new ByteSize("1GB");
        assertEquals(1024L * 1024 * 1024, bs.getBytes());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidUnitThrowsException() {
        new ByteSize("10XY"); // Invalid unit
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMalformedInputThrowsException() {
        new ByteSize("invalid"); // Malformed input
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEmptyInputThrowsException() {
        new ByteSize(""); // Empty string
    }
}
