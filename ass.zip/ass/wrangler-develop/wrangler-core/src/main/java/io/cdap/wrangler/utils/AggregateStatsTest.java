package io.cdap.wrangler.exec.Directive;

import io.cdap.wrangler.api.Arguments;
import io.cdap.wrangler.api.Row;
import io.cdap.wrangler.api.parser.ColumnName;
import io.cdap.wrangler.api.parser.Text;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

public class AggregateStatsTest {

    private Arguments createArguments(String type) {
        return new Arguments() {
            private final Map<String, Object> map = new HashMap<String, Object>() {{
                put("byteCol", new ColumnName("bytes"));
                put("timeCol", new ColumnName("duration"));
                put("outByteCol", new ColumnName("totalBytes"));
                put("outTimeCol", new ColumnName("totalDuration"));
                put("unit", new Text("MB"));
                put("timeUnit", new Text("seconds"));
                put("type", new Text(type));
            }};

            @Override
            public <T> T value(String name) {
                return (T) map.get(name);
            }

            @Override
            public boolean has(String name) {
                return map.containsKey(name);
            }

            @Override
            public Set<String> getNames() {
                return map.keySet();
            }
        };
    }

    @Test
    public void testTotalAggregation() {
        AggregateStats directive = new AggregateStats();
        directive.initialize(createArguments("total"));

        List<Row> rows = Arrays.asList(
            new Row().add("bytes", "1MB").add("duration", "2s"),
            new Row().add("bytes", "2MB").add("duration", "4s")
        );

        List<Row> result = directive.execute(rows, null);
        assertEquals(1, result.size());

        Row output = result.get(0);
        assertEquals(3.0, (double) output.getValue("totalBytes"), 0.001);
        assertEquals(6.0, (double) output.getValue("totalDuration"), 0.001);
    }

    @Test
    public void testAverageAggregation() {
        AggregateStats directive = new AggregateStats();
        directive.initialize(createArguments("average"));

        List<Row> rows = Arrays.asList(
            new Row().add("bytes", "1MB").add("duration", "2s"),
            new Row().add("bytes", "3MB").add("duration", "4s")
        );

        List<Row> result = directive.execute(rows, null);
        assertEquals(1, result.size());

        Row output = result.get(0);
        assertEquals(2.0, (double) output.getValue("totalBytes"), 0.001);
        assertEquals(3.0, (double) output.getValue("totalDuration"), 0.001);
    }
}
