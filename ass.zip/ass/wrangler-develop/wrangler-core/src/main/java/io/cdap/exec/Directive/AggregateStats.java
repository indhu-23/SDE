package io.cdap.wrangler.exec.Directive;

import io.cdap.wrangler.api.*;
import io.cdap.wrangler.api.parser.*;
import java.util.*;

public class AggregateStats implements Directive, Aggregate {
  private String byteCol, timeCol, outByteCol, outTimeCol;
  private String unit = "MB";
  private String timeUnit = "seconds";
  private String type = "total";

  private long totalBytes = 0;
  private long totalTimeMs = 0;
  private int count = 0;

  @Override
  public UsageDefinition define() {
    return UsageDefinition.builder()
      .directive("aggregate-stats")
      .usage("aggregate-stats <byteCol> <timeCol> <outByteCol> <outTimeCol> [unit=MB] [timeUnit=seconds] [type=total|average]")
      .build();
  }

  @Override
  public void initialize(Arguments args) {
    byteCol = ((ColumnName) args.value("byteCol")).value();
    timeCol = ((ColumnName) args.value("timeCol")).value();
    outByteCol = ((ColumnName) args.value("outByteCol")).value();
    outTimeCol = ((ColumnName) args.value("outTimeCol")).value();

    if (args.has("unit")) unit = ((Text) args.value("unit")).value();
    if (args.has("timeUnit")) timeUnit = ((Text) args.value("timeUnit")).value();
    if (args.has("type")) type = ((Text) args.value("type")).value();
  }

  @Override
  public AggregateInfo aggregate(ExecutorContext ctx) {
    return new AggregateInfo();
  }

  @Override
  public List<Row> execute(List<Row> rows, ExecutorContext ctx) {
    for (Row row : rows) {
      String byteStr = String.valueOf(row.getValue(byteCol));
      String timeStr = String.valueOf(row.getValue(timeCol));

      long bytes = new ByteSize(byteStr).getBytes();
      long millis = new TimeDuration(timeStr).getMilliseconds();

      totalBytes += bytes;
      totalTimeMs += millis;
      count++;
    }

    if (type.equalsIgnoreCase("average")) {
      totalBytes /= count;
      totalTimeMs /= count;
    }

    Row result = new Row();
    result.add(outByteCol, convertBytes(totalBytes));
    result.add(outTimeCol, convertTime(totalTimeMs));

    return Collections.singletonList(result);
  }

  private double convertBytes(long bytes) {
    switch (unit.toUpperCase()) {
      case "GB": return bytes / (1024.0 * 1024 * 1024);
      case "MB": return bytes / (1024.0 * 1024);
      case "KB": return bytes / 1024.0;
      default: return bytes;
    }
  }

  private double convertTime(long ms) {
    switch (timeUnit.toLowerCase()) {
      case "seconds": return ms / 1000.0;
      case "min": return ms / 60000.0;
      case "h": return ms / 3600000.0;
      default: return ms;
    }
  }
}
